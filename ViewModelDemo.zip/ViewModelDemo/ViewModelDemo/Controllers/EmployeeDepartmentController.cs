﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ViewModelDemo.Models;

namespace ViewModelDemo.Controllers
{
    public class EmployeeDepartmentController : Controller
    {
        // GET: EmployeeDepartment
        public ActionResult Index()
        {
            Employee employee = new Employee() { EmployeeId = 1, EmployeeName = "Manish", DepartmentId = 201, Salary = 12345 };
            Department department = new Department() { DepartmentId = 1, DepartmentName = "L&D", DepartmentLocation = "Airoli CGKP" };
            VMEmployeeDepartment vmEmployeeDepartment = new VMEmployeeDepartment()
            {
                EmployeeId = employee.EmployeeId,
                EmployeeName = employee.EmployeeName,
                DepartmentName = department.DepartmentName,
                DepartmentLocation = department.DepartmentLocation,
                Salary = employee.Salary
            };

            return View(vmEmployeeDepartment);
        }

        public ActionResult Index2()
        {
            Employee employee1 = new Employee() { EmployeeId = 1, EmployeeName = "Manish", DepartmentId = 201, Salary = 12345 };
            Employee employee2 = new Employee() { EmployeeId = 2, EmployeeName = "Amit", DepartmentId = 202, Salary = 23456 };
            Employee employee3 = new Employee() { EmployeeId = 3, EmployeeName = "Ketan", DepartmentId = 201, Salary = 34567 };
            Employee employee4 = new Employee() { EmployeeId = 4, EmployeeName = "Piyush", DepartmentId = 201, Salary = 45679 };
            Employee employee5 = new Employee() { EmployeeId = 5, EmployeeName = "Piyush", DepartmentId = 202, Salary = 45679 };

            Department department1 = new Department() { DepartmentId = 201, DepartmentName = "L&D", DepartmentLocation = "Airoli CGKP" };
            Department department2 = new Department() { DepartmentId = 202, DepartmentName = "Ops", DepartmentLocation = "Airoli B6" };


            List<Employee> Employees = new List<Employee>();
            Employees.Add(employee1);
            Employees.Add(employee2);
            Employees.Add(employee3);
            Employees.Add(employee4);
            Employees.Add(employee5);

            List<Department> departments = new List<Department>();
            departments.Add(department1);
            departments.Add(department2);
            List<VMEmployeeDepartment> vMEmployeeDepartments = 
                new List<VMEmployeeDepartment>();

            foreach (Employee employee in Employees)
            {
                VMEmployeeDepartment vmEmployeeDepartment = new VMEmployeeDepartment();
                vmEmployeeDepartment.EmployeeId = employee.EmployeeId;
                vmEmployeeDepartment.EmployeeName = employee.EmployeeName;

                Department department = departments.FirstOrDefault(dept => dept.DepartmentId == employee.DepartmentId);
                
                if(department.DepartmentId == employee.DepartmentId)
                {
                    vmEmployeeDepartment.DepartmentName = department.DepartmentName;
                    vmEmployeeDepartment.DepartmentLocation = department.DepartmentLocation;
                }
                vmEmployeeDepartment.Salary = employee.Salary;
                if(employee.Salary>25000)
                {
                    vmEmployeeDepartment.SalaryBackGroundColor = "red";
                }
                vMEmployeeDepartments.Add(vmEmployeeDepartment);
            }

            return View(vMEmployeeDepartments);
        }
    }
}